// Displays 5 random questions that the player can answer.
// Use radio buttons or inputs to collect the answer from the player.
// Upon completing the quiz, send the player’s answers to a service which will
// calculate the total score, POST the score to the server, and direct the player to
// the scores route.


const quizComponent = {
    template: `
    <p></p>
        <form ng-submit="">
        <section ng-repeat="item in $ctrl.questionList | limitTo: 5">
            <input type="text" placeholder="name">
            <p>Question: {{item.question}}</p>

            <input type="radio" value="{{item.choice_one}}" ng-click="$ctrl.checkAnswer(item.choice_one, item.answer, $index)" name={{item.id}}><p>{{item.choice_one}}</p>

            <input type="radio" value="{{item.choice_two}}" ng-click="$ctrl.checkAnswer(item.choice_two, item.answer, $index)"name="{{item.id}}"><p>{{item.choice_two}}</p>

            <input type="radio" value="{{item.choice_three}}" ng-click="$ctrl.checkAnswer(item.choice_three, item.answer, $index)" name="{{item.id}}"><p>{{item.choice_three}}</p>

            <input type="radio" value="{{item.choice_four}}" ng-click="$ctrl.checkAnswer(item.choice_four, item.answer, $index)" name="{{item.id}}"><p>{{item.choice_four}}</p>
        
        </section>
        </form>
    `,
    controller: ["QuizService", function(QuizService) {
        const vm = this;
        
        //calling response from QuizService and placing it in the questionList variable
        //YOU HAVE TO HAVE THIS WRITTEN OUT OTHERWISE NO DATA WILL BE ACCESSED
        QuizService.getQuestions().then(function(response){
            vm.questionList = response.data;
        })

    

        vm.score = 0;
        vm.result = [false, false, false, false, false]

        vm.checkAnswer = function(choice, answer, index) {
            if (choice == answer) {

                vm.result[index] = true;
            } else if (choice != answer) {

                vm.result[index] = false;
            }
            console.log(vm.result)

            console.log(vm.score)
            console.log(choice)
            console.log(answer)
        }

    }]
}





angular
    .module("App")
    .component("quizComponent", quizComponent)