"use strict";

// a. addScore - Take a guess at what this will do.
// b. getScores - Take a guess at what this will do.
// c. getQuestions - Take a guess at what this will do.

function QuizService($http) {
    const self = this;
    self.getQuestions = function(){
        return $http({
            method: "GET",
            url: "/questions"
        })
    }

    self.getScores = function() {
        return $http({
            method: "GET",
            url: "/scores"
        })
    }

    
} 


 









angular
    .module("App")    
    .service("QuizService", QuizService)                